void main()
{
  print("my address is here\ndarshan university\nrajkot morbi highway\trajkot city.");
}

// output :-

// my address is here
// dardhan university
// rajkot morbi highway     rajkot city.