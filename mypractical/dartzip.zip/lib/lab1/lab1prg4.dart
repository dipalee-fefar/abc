void main()
{
  print("Welcome to dart and flutter");
}


// output :-
// Welcome to dart and flutter