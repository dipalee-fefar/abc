package com.example.mypractical

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
